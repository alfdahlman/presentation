const init = async () => {
  console.log('init!');
};

init();